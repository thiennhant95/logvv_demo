<a href="index.php">Index.php</a>
<?php
//include('./common/Browser.php');
//$browser = new Browser();
//echo $browser->getBrowser();
//    if( $browser->getBrowser() == Browser::BROWSER_IE && $browser->getVersion() >= 8 )
//    {
//        echo "Your browser is Internet explorer version 8";
//    }
?>